MAX=int(input())
a = [[0 for i in range(MAX)] for i in range(MAX)]
print(a)