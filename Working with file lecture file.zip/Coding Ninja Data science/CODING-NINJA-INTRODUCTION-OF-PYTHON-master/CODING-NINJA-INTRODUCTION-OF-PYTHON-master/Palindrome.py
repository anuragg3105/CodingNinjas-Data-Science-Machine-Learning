num=input()
x="".join(reversed(num))
if num == x:
    print("true")
else:
    print("false")

    